#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

void   message_for_parents(pid_t pid);
void   wait_for_parents(void);
void   sig_func(int signo);
void   setup_signals(void);
double calculate_exp(long n, double x);

#define EXIT_MESSAGE "exited child 2"

struct sigaction sigact = {0};
sigset_t     sig_null;
int         signal_flag = false;

int main(int argc, char const *argv[]) {
    setup_signals();

    if (argc != 2) {
        printf("Usage: %s X\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    wait_for_parents(); // Wait for parent signal
    sleep(1);        // Wait 1 second

    long   n   = 4096;            // Number of iteration
    double x   = strtod(argv[1], NULL); // Read x from argv
    double exp = calculate_exp(n, x);   // Calculate Exp(x) with nth precision

    write(STDOUT_FILENO, &exp, sizeof(double)); // Write Exp
    sleep(1);                    // Wait 1 second
    message_for_parents(getppid());            // Notify parent aobut written data

    wait_for_parents();                      // Wait for parent signal
    write(STDOUT_FILENO, EXIT_MESSAGE, strlen(EXIT_MESSAGE)); // Write end message
    sleep(1);                          // Wait 1 second
    message_for_parents(getppid()); // Notify parent about written data

    return EXIT_SUCCESS;
}

void message_for_parents(pid_t pid) {
    kill(pid, SIGUSR2);
}

void wait_for_parents() {
    while (signal_flag == false) {
        sigsuspend(&sig_null);
    }

    signal_flag = false;
}

void sig_func(int signo) {
    signal_flag = true;
}

void setup_signals(void) {
    sigemptyset(&sigact.sa_mask);
    sigemptyset(&sig_null);

    sigaddset(&sigact.sa_mask, SIGUSR1);
    sigaddset(&sigact.sa_mask, SIGTERM);

    sigact.sa_flags      = SA_RESTART | SA_SIGINFO;
    sigact.sa_handler = &sig_func;

    if (sigaction(SIGUSR1, &sigact, NULL) == -1) {
        perror("can't setup SIGUSR1 signal");
        exit(EXIT_FAILURE);
    }

    if (sigaction(SIGTERM, &sigact, NULL) == -1) {
        perror("can't setup SIGTERM signal");
        exit(EXIT_FAILURE);
    }
}

double calculate_exp(long n, double x) {
    double exp = 1, mult = (1 + x / n);

    for (long i = 1; i <= n; ++i) {
        exp *= mult;
    }

    return exp;
}

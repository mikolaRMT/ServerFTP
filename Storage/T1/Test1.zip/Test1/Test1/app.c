#include <math.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define RD 0
#define WR 1

sigset_t sig_m1, sig_m2, sig_null;
int     signal_flag = false;

void start_signalset(void);
void sig_func(int signo);
void message_for_child(pid_t pid, int signo);
void wait_for_child(void);

int main() {
    start_signalset();

    pid_t pids[2];
    int   fds[2][2];

    if (pipe(fds[0]) < 0) {
        perror("can't create first pipe");
        exit(1);
    }

    pids[0] = fork();
    if (pids[0] == -1) {
        perror("Can't create first child process");
        exit(EXIT_FAILURE);
    }

    if (pids[0] == 0) {
        // child 1

        close(fds[0][RD]);         // Close read fd
        dup2(fds[0][WR], STDOUT_FILENO); // Dup piped write fd
        close(fds[0][WR]);         // Close write fd

        execl("pi", "pi", NULL);

        perror("can't run pi");
        exit(EXIT_FAILURE);
    }

    if (pipe(fds[1]) < 0) {
        perror("Can't create second pipe");
        exit(EXIT_FAILURE);
    }
    pids[1] = fork();

    if (pids[1] == 0) {
        // child 2
        close(fds[1][RD]);         // Close read fd
        dup2(fds[1][WR], STDOUT_FILENO); // Dup piped write fd
        close(fds[1][WR]);         // Close write fd

        char X[128];
        sprintf(X, "%lf", -(double)(1 * 1) / 2);
        execl("exp", "exp", X, NULL);

        perror("can't run exp");
        exit(EXIT_FAILURE);
    }

    // Close write ends
    close(fds[0][WR]);
    close(fds[1][WR]);

    puts("Parent after create childs");

    char   buf[15] = {0};
    double pi, exp;

    // signal to child 2 to run
    message_for_child(pids[1], SIGUSR1);
    wait_for_child();

    // read from child 2
    read(fds[1][RD], &exp, sizeof(double));
    printf("Exp: %lf\n", exp);

    // signal to child 1 to run
    message_for_child(pids[0], SIGUSR1);
    wait_for_child();

    // read from child 1
    read(fds[0][RD], &pi, sizeof(double));
    printf("PI: %lf\n", pi);

    // kill child 1
    message_for_child(pids[0], SIGTERM);
    wait_for_child();

    // read exit message from child 1
    read(fds[0][RD], buf, 14);
    printf("%s\n", buf);

    // kill child 2
    message_for_child(pids[1], SIGTERM);
    wait_for_child();

    // read exit message from child 2
    read(fds[1][RD], buf, 14);
    printf("%s\n", buf);

    // Close read ends
    close(fds[0][RD]);
    close(fds[1][RD]);

    printf("Result: %lf\n", exp / sqrt(2 * pi));
    return 0;
}

void sig_func(int signo) {
    start_signalset();
    signal_flag = true;
}

void start_signalset(void) {
    if (signal(SIGUSR1, sig_func) == SIG_ERR) {
        exit(0);
    }

    if (signal(SIGUSR2, sig_func) == SIG_ERR) {
        exit(0);
    }

    sigemptyset(&sig_m1);
    sigemptyset(&sig_null);
    sigaddset(&sig_m1, SIGUSR1);
    sigaddset(&sig_m1, SIGUSR2);

    if (sigprocmask(SIG_BLOCK, &sig_m1, &sig_m2) < 0) {
        exit(0);
    }
}

void message_for_child(pid_t pid, int signo) {
    kill(pid, signo);
}

void wait_for_child(void) {
    while (signal_flag == false) {
        sigsuspend(&sig_null);
    }

    signal_flag = false;

    if (sigprocmask(SIG_SETMASK, &sig_m2, NULL) < 0) {
        exit(0);
    }
}
